﻿
using Microsoft.AspNetCore.Mvc;
using assignement_4.Data;
using Microsoft.EntityFrameworkCore;
using modelsweb;
using Microsoft.AspNetCore.Http.HttpResults;


namespace assignement_4.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Controller
    {
        public AppDbContext Context = new AppDbContext(new DbContextOptions<AppDbContext>());
        [HttpGet]
        public async Task <IActionResult> Getinfo()
        {
            var add = await Context.Employee.ToListAsync();
            return Ok("successfull");
        }
    }
})