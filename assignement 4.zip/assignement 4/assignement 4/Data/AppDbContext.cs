﻿using Microsoft.EntityFrameworkCore;
using modelsweb;

namespace assignement_4.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder()
                   .SetBasePath(Directory.GetCurrentDirectory())
                   .AddJsonFile("appsettings.json")
                   .Build();
                var connectionString = configuration.GetConnectionString("dbConnection");
                optionsBuilder.UseSqlServer(connectionString);
            }
        }
        public DbSet<Employee> Employee { get; set; }

         
    }
}
